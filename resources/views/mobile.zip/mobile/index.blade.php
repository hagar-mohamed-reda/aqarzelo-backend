@php

if (session("locale"))
    App()->setLocale(session("locale")); 
else
    App()->setLocale("ar"); 

@endphp
<!DOCTYPE html>
<html lang="{{ session('locale')? session('locale'): 'ar' }}" > 
    <head> 
        @yield("css") 
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

        <!-- css section --> 
        @include("website.component.css") 

        <title>aqar zelo</title>
            <!-- Compiled and minified CSS --> 

        @if (session("locale") == "ar")
        <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet">

        <style type="text/css">
            * {
                font-family: 'Cairo', sans-serif; 
            }
        
        </style>
        @endif

        <style type="text/css">
            
             
            .application-container {
                border-top-left-radius: 2em;
                border-top-right-radius: 2em;
                background-color: white;
                overflow: hidden;
                background: white; 
            }
            
            .application-header {
                height: 80px;
            }
         
            .application-bottom-nav {
                border-top-left-radius: 2em;
                border-top-right-radius: 2em;
                background-color: white;
            }

            .bottom-nav-content {
                height: 60px;
                border-radius: 5em;
                /*background-color: #DEDEDE;*/
            }
        </style>
    </head>

    <body>    
        <div id="root" v-html="content" >
            
        </div>
    </body>  

    <!-- css section --> 
    @include("website.component.js") 
    
    <!-- Compiled and minified JavaScript --> 
           
    
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script type="text/javascript"> 
        var BASE_URL = "{{ url('/api') }}";
        
        function loadSplash() {
            $.get("{{ url('/splash') }}", function(r){
                $('#root').html(r);
            });
        }

        function formatCurrency(number) {
            
        }
        
        function getLocation(action) {
            if (navigator.geolocation)
                navigator.geolocation.getCurrentPosition(function (position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                    
                    if (action)
                        action({lat: lat, lng: lng});
                });
        }
        
        function loadPage(path, action) { 
            $.get(public_path + "/" + path, function(r){
                $('#root').html(r);
                if (action)
                    action(r);
            });
        }
        
        function errorToast(message) { 
            playSound("not2");
            iziToast.show({
                class: 'w3-pale-red shadow izitoast',
                timeout: 2000,
                message: message,
            });
        }
        
        function successToast(message) { 
            playSound("not2");
            iziToast.show({
                class: 'w3-green shadow izitoast',
                timeout: 2000,
                message: message,
            });
        }
    </script>
    <script>   
        var app = new Vue({
            el: '#root',
            data: {
                api_token: window.localStorage.getItem("api_token"),
                content: ''
            },
            methods: {

            },
            computed: {
                height: function(){
                    return window.innerHeight;
                }
            }
        });

        $(document).ready(function(){
            // set full screen
            //document.documentElement.requestFullscreen();
            
            // load splash screen
            loadSplash();
        });
    </script>
</html>
