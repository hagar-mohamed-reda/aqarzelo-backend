
                <div class="application-bottom-nav w3-display-bottomleft w3-block w3-padding shadow w3-white" style="position: fixed;!important" >
                    <div class="w3-block bottom-nav-content w3-padding w3-row w3-light-grey " >
                        <div 
                        onclick="loadPage('/phone/home')"
                        class="w3-center btn fa fa-map-marker w3-xxlarge w3-text-gray home-bottom-nav-item  light-theme-color-hover w3-col l3 m3 s3" ></div>

                        <div 
                        onclick="loadPage('phone/post/create')" 
                        class="w3-center btn fa fa-plus-circle w3-xxlarge w3-text-gray create-post-bottom-nav-item  light-theme-color-hover w3-col l3 m3 s3" ></div>

                        <div  
                        onclick="loadPage('/phone/favourite')"
                        class="w3-center btn fa fa-heart w3-xxlarge w3-text-gray favourite-bottom-nav-item  light-theme-color-hover w3-col l3 m3 s3" ></div>

                        <div 
                            onclick="loadPage('/phone/notification')"
                            class="w3-center btn fa fa-bell w3-xxlarge w3-text-gray notification-bottom-nav-item  light-theme-color-hover w3-col l3 m3 s3" ></div>
                    </div>
                </div>