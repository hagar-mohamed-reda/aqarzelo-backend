<div 
class="w3-modal post-loader" 
style="background: rgba(0,0,0,.6);padding-top: 50%!important;z-index: 9999999!important" >
	
	<center>
		<img src="{{ url('/mobile/images/logo.png') }}" class="animated bounceIn infinite"  width="60vw" >
		<br>
		<br>
		<b class="w3-large w3-text-shadow w3-text-white" >{{ __('mobile.please_wait') }}..</b>
	</center>



</div>