<!-- css styles  -->
<style type="text/css">
    .home { 
        background-size: 100% 100%; 
        background-repeat: no-repeat;
        width: 100%; 
        background: #DEDEDE; 
        }

        .w3-modal-content {
            background-color: transparent!important;
        }
        
             
            .application-container {
                border-top-left-radius: 2em;
                border-top-right-radius: 2em;
                background-color: white;
                overflow: hidden;
                background: #DEDEDE; 
            }
            
            .application-header {
                height: 80px;
            }
        
        
        .result-show {
            bottom: 80px; 
            background-color: transparent;
            overflow-x: auto; 
        }
        
        .result-show-item {
            border-radius: 1em;
            overflow: hidden;
            background-color: white; 
        }
        
        .result-show-item img { 
            height: 140px;
        }

        .application-grad-back {
            background-image: url({{ url('/mobile/images/back-gradient.png') }});
            background-size: 100%;
            background-position: bottom;
            background-repeat: no-repeat;
            width: 100%;
            height: 200px;
        }
        
        .post-show-image-container {
            background-size: cover;
            width: 200%;
            height: 200px;
        }
        
    </style>

    <!-- html content -->
    <div class="home dark-theme-background" id="page" v-bind:style="'height: ' + height + 'px'" >
        <div class="application-header" >
            <br>
            <div class="w3-bar w3-padding">
              <a href="#" class="w3-bar-item btn">
                  <img v-bind:src="photo" v-if="api_token" class="w3-circle" onclick="loadPage('phone/setting')" width="30px" >

                  <img src="{{ url('/mobile/images/avatar.png') }}" v-if="!api_token" onclick="loadPage('phone/setting')" width="30px" >
              </a> 
              <a href="#" class="w3-bar-item btn w3-right " onclick="loadPage('phone/filter')" >
                  <img src="{{ url('/mobile/images/bars.png') }}" width="30px" >
              </a>
            </div>
        </div>
        <div class="application-container w3-display-container" v-bind:style="'height: ' + (height - 80) + 'px'" >
            <div id="map" class="w3-block"  style="height: 100%" ></div>
            
            <div  class="application-grad-back w3-display-bottommiddle" >

                <!-- application bottom nav -->
                @include("mobile.bottomNav")

                <div class="result-show w3-display-bottomleft w3-block" >
                    <div class="owl-carousel owl-theme" style="width: 100%" >
                        <div class="item" v-for="post in posts" >
                            <div class="result-show-item shadow" onclick="loadPage('phone/post/show?post_id='+$(this).attr('data-id'))" v-bind:data-id="post.id" >
                                <img v-if="post.images[0]" v-bind:src="post.images[0].image" >
                                <br>
                                <div class="w3-padding" >
                                    <div class="w3-large" ><b v-html="post.title.substring(0,15)+'..'" ></b></div>
                                    <span v-html="post.price" ></span>  
                                    <span v-html="post.space" ></span> M
                                </div>
                            </div>
                        </div> 
                    </div>
                    <br>

                </div>
            </div>
        </div>
        
        
        

    
        <!-- post show modal --> 
        <div class="modal fade post-show-modal" id="show-post-modal" tabindex="-1" role="dialog" style="z-index: 9999!important">
            <div class="modal-dialog" role="document" style="padding-top: 45%" >
               
                <div class="modal-content light-theme-background w3-text-white w3-display-container" style="overflow: hidden" >
                    <img 
                        v-if="currentPost.images" 
                        v-bind:src="currentPost.images? currentPost.images[0].image : '{{ url('/mobile/images/image.png') }}'" class='w3-block hidden' >
                    <div 
                        v-bind:style=" 'background-image: url(' + (currentPost.images? currentPost.images[0].image : '{{ url('/mobile/images/image.png') }}') + ')' "
                        class="post-show-image-container" > 
                    </div>
                    <div class="modal-body" >
                        <div class="w3-large" >
                            <b class="" v-html='currentPost.title? currentPost.title : ""' ></b>
                        </div>
                        <div>
                            <b class="post-show-price" v-if="currentPost.price" v-html='format(currentPost.price)' ></b>
                            <b class="post-show-space" v-if="currentPost.space" v-html='currentPost.space + " M"' ></b>
                        </div>
                    </div>
                    
                    <div class="w3-display-topright w3-padding" >
                        <img class="w3-circle shadow" width="30px" height="30px" v-if="currentPost.user" v-bind:src="currentPost.user.company.photo_url"   >
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- javascript -->
    
    <script>
        var path = "{{ request()->path }}";
        var lat = null
        var lng = null;
        var map;
        var marker = null;
        var markers = [];
        var placeMarker = null;
        
        function loadPosts() {
            var data = $.param(page.search);
            $.get(BASE_URL + "/post/search?"+data, function(r){
                page.posts = r.data;
                drawPostsMarkers(page.posts);
                setTimeout(function(){ 
                    if (page.posts.length > 0)
                        setOwlCarousel();
                }, 1000);

                if (page.posts.length <= 0)
                    loadRecommendPosts();
            });
        }

        function loadRecommendPosts() {
            //var data = $.param(page.search);
            $.get(BASE_URL + "/post/recommended", function(r){
                page.posts = r.data;
                drawPostsMarkers(page.posts);
                setTimeout(function(){ 
                    if (page.posts.length > 0)
                        setOwlCarousel();
                }, 1000);
            });
        }

        function addMarker(location, label, action) {
            var icon = public_path + "/mobile/images/pin.png";
            // Add the marker at the clicked location, and add the next-available label
            // from the array of alphabetical characters.
            var marker = new google.maps.Marker({
                position: location,
                map: map,
                animation: google.maps.Animation.DROP, 
                icon: {
                  url: icon,
                  labelOrigin: { x: 12, y: 40}
                },
                title: label, 
                label: { backgroundColor: '#fff', color: '#02aaa8', fontWeight: 'bold', fontSize: '14px', text: label }, 
                labelInBackground: true
            });
            

            marker.addListener('click', function () {
                if (action)
                    action();
            }); 
            return marker;
        }
        /**
         * set all posts marker on the map
         * 
         * @param {Array} posts
         */
        function drawPostsMarkers(posts) {
       
            for (var i = 0; i < posts.length; i++) {
                var post = posts[i];  

                var marker = addMarker({lat: parseFloat(post.lat), lng: parseFloat(post.lng)}, post.price+"", function(){
                   showCurrentPost(post);
                });
                markers.push(marker);
            }
        }
        
        function showCurrentPost(post) {
            page.currentPost = post; 
            $('#show-post-modal').modal('show');
        }


        function setOwlCarousel() {
            $('.owl-carousel').owlCarousel({
                loop:true,
                center:true,
                margin:10,
                dots: false,
                nav:false,
                responsive:{
                    0:{
                        items:2
                    },
                    400:{
                        items:2
                    },
                    600:{
                        items:3
                    },
                    800:{
                        items:3
                    },
                    1000:{
                        items:4
                    }
                }
            });
        }
        
        function getCurrentLocation() {
            getLocation(function(latlng){
                lat=latlng.lat; 
                lng = latlng.lng;  
                var p = new google.maps.LatLng(lat, lng);
                placeMarker(p, map);
            });
        }

        function initMap() { 
            map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: 30.0455965, lng: 31.2387195},
                zoom: 12
            });

            google.maps.event.addListener(map, 'click', function (e) {
                placeMarker(e.latLng, map);
            });

            placeMarker = function(position, map) {
                try {
                    marker.setMap(null);
                } catch (e) {
                }
                marker = new google.maps.Marker({
                    position: position,
                    map: map
                });
                lat = position.lat();
                lng = position.lng();
 
                map.panTo(position);
            }

        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD4ow5PXyqH-gJwe2rzihxG71prgt4NRFQ&libraries=places&callback=initMap"
    async defer></script>

    
    <script> 
        var page = new Vue({
            el: '#page',
            data: {
                currentPost: {},
                posts: [],
                search: {},
                photo: window.localStorage.getItem("photo"),
                api_token: window.localStorage.getItem("api_token"),
                h: 100
            },
            methods: {
                format: function(n) {
                    return n.toLocaleString('en-US', { style: 'currency', currency: 'EGP'});
                }
            },
            computed: {
                height: function () {
                    return window.innerHeight;
                }
            }
        }); 
        
        $(document).ready(function(){  
            
            @if (request()->lng && request()->lat)
                page.search.lat = {{ request()->lat }};
                page.search.lng = {{ request()->lng }};
            @elseif (request()->space1 && request()->space2)
                page.search.space1 = {{ request()->space1 }};
                page.search.space2 = {{ request()->space2 }};
            @elseif (request()->price1 && request()->price2)
                page.search.price1 = {{ request()->price1 }};
                page.search.price2 = {{ request()->price2 }};
            @elseif (request()->bedroom_number)
                page.search.bedroom_number = {{ request()->bedroom_number }}; 
            @elseif (request()->bathroom_number)
                page.search.bathroom_number = {{ request()->bathroom_number }}; 
            @elseif (request()->city_id)
                page.search.city_id = {{ request()->city_id }}; 
            @elseif (request()->area_id)
                page.search.area_id = {{ request()->area_id }}; 
            @elseif (request()->category_id)
                page.search.category_id = {{ request()->category_id }}; 
            @endif 
             
            loadPosts();
            //
            $(".home-bottom-nav-item").addClass("light-theme-color");
        });
    </script>